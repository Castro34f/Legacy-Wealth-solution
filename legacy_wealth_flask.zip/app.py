
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from pathlib import Path

APP_NAME = "Legacy Wealth Solution"
DB_PATH = Path("app.db")

app = Flask(__name__, static_url_path="/static")
app.secret_key = "change-this-in-production"

# ---------------- DB helpers ----------------
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        balance REAL DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        type TEXT NOT NULL, -- deposit | withdrawal
        method TEXT NOT NULL,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'pending', -- pending|completed|rejected
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY CHECK (id=1),
        btc_address TEXT, eth_address TEXT, usdt_trc20 TEXT,
        skrill_email TEXT, neteller_email TEXT, usdt_withdraw TEXT,
        two_factor INTEGER DEFAULT 0, dark_mode INTEGER DEFAULT 0,
        push_notifications INTEGER DEFAULT 1, marketing_emails INTEGER DEFAULT 0
    );
    INSERT OR IGNORE INTO settings (id, btc_address, eth_address, usdt_trc20, skrill_email, neteller_email, usdt_withdraw)
    VALUES (1, '', '', '', '', '', '');
    """)
    # seed admin if missing
    row = db.execute("SELECT COUNT(*) AS c FROM users").fetchone()
    if row["c"] == 0:
        db.execute("INSERT INTO users (name, email, password_hash, is_admin, balance) VALUES (?,?,?,?,?)",
                   ("Admin", "admin@example.com", generate_password_hash("admin123"), 1, 0))
        db.execute("INSERT INTO users (name, email, password_hash, is_admin, balance) VALUES (?,?,?,?,?)",
                   ("John Doe", "john@example.com", generate_password_hash("password"), 0, 20000))
        db.execute("INSERT INTO transactions (user_id, type, method, amount, status, created_at) VALUES (?,?,?,?,?,?)",
                   (2, "deposit", "Bitcoin (BTC)", 20000, "completed", "2025-05-20 10:00:00"))
    db.commit()

@app.before_request
def ensure_db():
    init_db()

# -------------- helpers --------------
def current_user():
    if 'user_id' in session:
        db = get_db()
        return db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    return None

def login_required(view):
    from functools import wraps
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    from functools import wraps
    @wraps(view)
    def wrapped(*args, **kwargs):
        u = current_user()
        if not u or not u["is_admin"]:
            flash("Admin access required.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped

# -------------- auth --------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            flash("Welcome back!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid credentials.", "danger")
    return render_template("auth_login.html", app_name=APP_NAME)

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name","").strip()
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        if not name or not email or not password:
            flash("All fields are required.", "warning")
            return redirect(url_for("signup"))
        db = get_db()
        try:
            db.execute("INSERT INTO users (name, email, password_hash) VALUES (?,?,?)",
                       (name, email, generate_password_hash(password)))
            db.commit()
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email already registered.", "danger")
    return render_template("auth_signup.html", app_name=APP_NAME)

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("login"))

# -------------- pages --------------
@app.route("/")
def home():
    return render_template("home.html", app_name=APP_NAME, user=current_user())

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    u = current_user()
    # summarize user tx
    deposited = db.execute("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE user_id=? AND type='deposit' AND status='completed'", (u["id"],)).fetchone()["s"]
    withdrawn = db.execute("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE user_id=? AND type='withdrawal' AND status='completed'", (u["id"],)).fetchone()["s"]
    profit = u["balance"] - deposited + withdrawn
    roi = (profit / deposited * 100) if deposited else 0
    recent = db.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 8", (u["id"],)).fetchall()
    return render_template("dashboard.html", app_name=APP_NAME, user=u, deposited=deposited, withdrawn=withdrawn, profit=profit, roi=roi, recent=recent)

@app.route("/portfolio")
@login_required
def portfolio():
    u = current_user()
    return render_template("portfolio.html", app_name=APP_NAME, user=u)

@app.route("/transactions")
@login_required
def transactions():
    u = current_user()
    db = get_db()
    items = db.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC", (u["id"],)).fetchall()
    return render_template("transactions.html", app_name=APP_NAME, user=u, items=items)

@app.route("/settings", methods=["GET","POST"])
@login_required
def settings():
    u = current_user()
    db = get_db()
    s = db.execute("SELECT * FROM settings WHERE id=1").fetchone()
    if request.method == "POST":
        # update deposit/withdraw details
        fields = ("btc_address","eth_address","usdt_trc20","skrill_email","neteller_email","usdt_withdraw")
        values = [ request.form.get(f,"") for f in fields ]
        db.execute("UPDATE settings SET btc_address=?, eth_address=?, usdt_trc20=?, skrill_email=?, neteller_email=?, usdt_withdraw=? WHERE id=1", values)
        db.commit()
        flash("Settings updated.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html", app_name=APP_NAME, user=u, s=s)

@app.route("/support")
def support():
    return render_template("support.html", app_name=APP_NAME, user=current_user())

@app.route("/about")
def about():
    return render_template("about.html", app_name=APP_NAME, user=current_user())

# -------------- deposit/withdraw endpoints --------------
@app.route("/deposit", methods=["POST"])
@login_required
def deposit():
    u = current_user()
    method = request.form.get("method")
    amount = float(request.form.get("amount","0") or 0)
    if amount <= 0:
        flash("Enter a valid amount.", "warning")
        return redirect(url_for("dashboard"))
    db = get_db()
    db.execute("INSERT INTO transactions (user_id, type, method, amount, status) VALUES (?,?,?,?,?)",
               (u["id"], "deposit", method, amount, "pending"))
    db.commit()
    flash("Deposit created. Admin will approve shortly.", "info")
    return redirect(url_for("transactions"))

@app.route("/withdraw", methods=["POST"])
@login_required
def withdraw():
    u = current_user()
    amount = float(request.form.get("amount","0") or 0)
    method = request.form.get("method")
    if amount <= 0:
        flash("Enter a valid amount.", "warning")
        return redirect(url_for("dashboard"))
    if amount > u["balance"]:
        flash("Insufficient balance.", "danger")
        return redirect(url_for("dashboard"))
    db = get_db()
    db.execute("INSERT INTO transactions (user_id, type, method, amount, status) VALUES (?,?,?,?,?)",
               (u["id"], "withdrawal", method, amount, "pending"))
    db.commit()
    flash("Withdrawal request submitted. Admin will process it.", "info")
    return redirect(url_for("transactions"))

# -------------- admin --------------
@app.route("/admin")
@admin_required
def admin_dashboard():
    db = get_db()
    users = db.execute("SELECT id, name, email, balance, is_admin FROM users ORDER BY created_at DESC").fetchall()
    pending = db.execute("SELECT t.*, u.email FROM transactions t JOIN users u ON u.id=t.user_id WHERE t.status='pending' ORDER BY t.created_at ASC").fetchall()
    return render_template("admin/dashboard.html", app_name=APP_NAME, user=current_user(), users=users, pending=pending)

@app.route("/admin/user/<int:user_id>/adjust", methods=["POST"])
@admin_required
def admin_adjust(user_id):
    delta = float(request.form.get("delta","0") or 0)
    note = request.form.get("note","Manual adjustment")
    db = get_db()
    db.execute("UPDATE users SET balance = balance + ? WHERE id=?", (delta, user_id))
    db.execute("INSERT INTO transactions (user_id, type, method, amount, status, notes) VALUES (?,?,?,?,?,?)",
               (user_id, "adjustment", note, abs(delta), "completed", datetime.utcnow().isoformat(timespec='seconds')))
    db.commit()
    flash("Balance adjusted.", "success")
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/tx/<int:tx_id>/<action>", methods=["POST"])
@admin_required
def admin_tx_action(tx_id, action):
    db = get_db()
    tx = db.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx or tx["status"] != "pending":
        flash("Invalid transaction.", "warning")
        return redirect(url_for("admin_dashboard"))
    # complete or reject
    if action == "approve":
        if tx["type"] == "deposit":
            db.execute("UPDATE users SET balance = balance + ? WHERE id=?", (tx["amount"], tx["user_id"]))
        elif tx["type"] == "withdrawal":
            db.execute("UPDATE users SET balance = balance - ? WHERE id=?", (tx["amount"], tx["user_id"]))
        db.execute("UPDATE transactions SET status='completed' WHERE id=?", (tx_id,))
        flash("Transaction approved.", "success")
    else:
        db.execute("UPDATE transactions SET status='rejected' WHERE id=?", (tx_id,))
        flash("Transaction rejected.", "info")
    db.commit()
    return redirect(url_for("admin_dashboard"))

# -------------- run --------------
if __name__ == "__main__":
    app.run(debug=True)
